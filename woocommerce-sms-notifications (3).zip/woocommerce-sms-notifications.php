<?php
/**
 * Plugin Name: WooCommerce SMS Notifications
 * Description: Sends SMS notifications to customers based on WooCommerce order status.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include necessary functions
include_once('includes/admin-settings.php');
include_once('includes/sms-functions.php');

// Hook into WooCommerce order status changes
add_action('woocommerce_order_status_changed', 'wc_send_sms_on_status_change', 10, 4);
?>
